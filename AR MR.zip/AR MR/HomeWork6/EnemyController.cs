﻿public sealed class EnemyController : UnitController
{
    #region UnityMethods

    protected override void Update()
    {
        base.Update();

        if (!_isDead && UnitManager.player.health != null)
        {
            if (Vector3.Distance(UnitManager.player.transform.position, UnitManager.enemy.transform.position) <=
                maxDistance)
            {
                _combat.Attack(UnitManager.player.health);
            }

            Vector3 playerPos = UnitManager.player.transform.position;
            playerPos.y = transform.position.y;

            Vector3 relativePos = playerPos - transform.position;
            transform.rotation = Quaternion.LookRotation(relativePos);
            _combat.Attack(UnitManager.player.health);
        }
    }

    #endregion


    #region Methods

    protected override void Die()
    {
        base.Die();

        UnitManager.enemy = null;
    }

    #endregion
}
