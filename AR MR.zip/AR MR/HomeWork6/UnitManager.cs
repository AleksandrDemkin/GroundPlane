﻿using UnityEngine;


public sealed class UnitManager : MonoBehaviour
{
    #region Fields

    public static UnitController player;
    public static UnitController enemy;

    #endregion


    #region Methods

    public void SetPlayerTarget(UnitController unit)
    {
        player = unit;
    }

    public void SetEnemyTarget(UnitController unit)
    {
        enemy = unit;
    }

    public void ResetPlayerTarget()
    {
        player = null;
    }

    public void ResetEnemyTarget()
    {
        enemy = null;
    }

    #endregion
}