﻿using Vuforia;


public sealed class PlayerController : UnitController
{
    #region Fields

    private VirtualButtonBehaviour _button;

    #endregion


    #region UnityMethods

    private void Start()
    {
        _button = gameObject.transform.parent.GetComponentInChildren<VirtualButtonBehaviour>();
        _button.RegisterOnButtonPressed(OnVirtualPressed);
    }

    #endregion


    #region Methods

    public void OnVirtualPressed(VirtualButtonBehaviour vb)
    {
        if (vb.VirtualButtonName.Equals("AttackButton")) Attack();
    }

    private void Attack()
    {
        if (!_isDead && UnitManager.enemy.health != null)
        {
            _combat.Attack(UnitManager.enemy.health);
        }
    }

    protected override void Die()
    {
        base.Die();
        UnitManager.player = null;
    }

    #endregion
}
