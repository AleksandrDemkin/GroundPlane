﻿using UnityEngine.Events;
using UnityEngine;


public sealed class Combat : MonoBehaviour
{
    #region Fields

    public UnityEvent OnAttack;

    [SerializeField] private int _damage = 1;
    [SerializeField] private float _cooldown = 1f;

    private float _cooldownTimer;

    #endregion


    #region UnityMethods

    void Update()
    {
        if (_cooldownTimer > 0)
        {
            _cooldownTimer -= Time.deltaTime;
        }
    }

    #endregion


    #region Methods

    public void Attack(Health health)
    {
        if (_cooldown > 0) return;

        OnAttack?.Invoke();
        health.AcceptDamage(_damage);
        _cooldownTimer = _cooldown;
    }

    #endregion
}
