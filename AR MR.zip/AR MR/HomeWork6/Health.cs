﻿using UnityEngine;


public sealed class Health : MonoBehaviour
{
    #region Fields

    [SerializeField] private int _maxHealth = 10;

    private int _currentHealth;

    #endregion


    #region Properties

    public int CurrentHealth => _currentHealth;

    #endregion


    #region UnityMethods

    void Start()
    {
        _currentHealth = _maxHealth;
    }

    #endregion


    #region Methods

    public void AcceptDamage(int damage)
    {
        _currentHealth = _currentHealth > damage ? _currentHealth -= damage : 0;
    }

    #endregion
}
