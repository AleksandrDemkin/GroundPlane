﻿using UnityEngine;


public class UnitController : MonoBehaviour
{
    #region Fields
    
    [SerializeField] protected Combat _combat;

    public Health health;

    protected bool _isDead = false;

    #endregion


    #region UnityMethods

    protected virtual void Update()
    {
        if (!_isDead && health.CurrentHealth == 0) Die();
    }

    #endregion


    #region Methods

    protected virtual void Die()
    {
        _isDead = true;
    }

    #endregion
}
